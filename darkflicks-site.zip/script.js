
// Animate "Welcome to DrakFlicks" one character at a time
const title = document.getElementById('title');
const fullText = "Welcome to DrakFlicks";
let index = 0;

function type() {
  title.textContent = fullText.slice(0, index) + (index % 2 === 0 ? "|" : "");
  index++;
  if (index <= fullText.length) {
    setTimeout(type, 150);
  }
}
type();
